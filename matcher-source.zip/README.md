# Matcher 学生登録 — GitHub Pages

株式会社ビズリク向けの静的なReactフォームです。必須項目は氏名・学部・学年・LINE URLで、紹介者氏名と学生証の提出は任意です。「以前アップロード済み」「今回は提出しない」に対応しています。

## ビルド

Node.js 22.13以上とpnpm 11.19を使用します。依存関係は `pnpm-lock.yaml` に固定しています。

```sh
pnpm install --frozen-lockfile
pnpm test
pnpm build
pnpm preview
```

公開するのは `dist/` の内容です。Viteの `base: './'` と `document.baseURI` を基準にしたOCRファイル参照により、GitHub Pagesのリポジトリ配下のURLと独自ドメインのルートの両方に対応しています。`public/.nojekyll` はビルド先にコピーされます。

## 登録先

送信先は `src/lib/runtime.ts` に固定した公開APIです。

`https://gakusho-scan-glow.hayato-saito560683.chatgpt.site/api/matcher/register`

ブラウザは `credentials: 'omit'` で送信します。公開前に、API側で実際のGitHub Pages originに対するCORSと `OPTIONS` を有効にする必要があります。API側が既存のGoogle Apps Scriptへ転記し、Google Sheetsと制限されたDriveフォルダに保存します。このリポジトリにはサーバー実装、シートID、認証情報、実際の登録データを含めません。

成功表示は、APIが成功と同じ受付IDを返した場合だけ行います。通信結果が不明な場合は、同じ受付IDと内容を使う確認ボタンを表示します。自動再送は行いません。

## OCR

文字読み取りはブラウザ内のTesseract.jsで実行します。エンジン・日本語・英語辞書は `public/ocr/` に同梱しています。ライセンスと辞書の出典も同じフォルダにあります。OCRの結果は入力補助として表示され、利用者が確認・修正できます。

`pnpm test` はリポジトリ配下のOCR参照、登録先、Cookie等を送らない設定、受付IDの維持、自動再送がないことをローカルのモックで確認します。実際のAPIへ送信しません。
