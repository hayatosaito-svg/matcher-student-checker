import { createRoot } from 'react-dom/client';
import MatcherForm from './components/matcher-form';
import './styles.css';

const root = document.getElementById('root');
if (!root) throw new Error('フォームを表示する領域がありません。');
createRoot(root).render(<MatcherForm />);
