export const schoolYears = [
  '1年',
  '2年',
  '3年',
  '4年',
  '5年',
  '6年',
  '修士1年',
  '修士2年',
  '博士1年',
  '博士2年',
  '博士3年',
  'その他',
] as const;
export type MatcherProfile = {
  name: string;
  faculty: string;
  schoolYear: string;
  lineUrl: string;
  referrerName: string;
};
export type ExtractedProfile = {
  name: string;
  faculty: string;
  schoolYear: string;
};
export type MatcherRegistration = {
  schemaVersion: 2;
  requestId: string;
  profile: MatcherProfile;
  submissionStatus: 'uploaded' | 'previous' | 'skipped';
  evidence: 'id' | 'mypage' | null;
  photo: string | null;
  photoCount: number;
  extracted: ExtractedProfile | null;
  consent: { privacy: boolean };
};
export function validLineUrl(value: string): boolean {
  if (value.length > 500 || /[\s\\#]/.test(value)) return false;
  return /^https:\/\/(?:line\.me\/(?:R\/)?ti\/p\/[^/?#:@]+|lin\.ee\/[^/?#:@]+)(?:\?[^#\s]*)?$/.test(
    value,
  );
}
export function matcherProfileError(p: MatcherProfile): string {
  if (!p.name.trim()) return '氏名を入力してください。';
  if (!p.faculty.trim()) return '学部を入力してください。';
  if (!(schoolYears as readonly string[]).includes(p.schoolYear))
    return '学年を選択してください。';
  if (!validLineUrl(p.lineUrl.trim()))
    return 'LINEの友だち追加URL（https://line.me/ti/p/… など）を入力してください。';
  return '';
}
/** Only explicit printed labels are used. Ambiguous/absent text remains blank. */
export function extractMatcherProfile(text: string): ExtractedProfile {
  const lines = text
    .normalize('NFKC')
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);
  const result: ExtractedProfile = { name: '', faculty: '', schoolYear: '' };
  const nameLabel = /^(?:氏\s*名|名\s*前|Name)\s*[:：]?\s*(.*)$/i;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const match = line.match(nameLabel);
    if (match && !result.name) {
      const candidate = (match[1] || lines[i + 1] || '').trim();
      if (
        candidate.length <= 60 &&
        /^[\p{L}々・ー .'-]+$/u.test(candidate) &&
        !/(学部|学年|番号|生年月日|有効)/.test(candidate)
      )
        result.name = candidate;
    }
    const faculty = line.match(
      /(?:^|[ :：])([\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}ー・A-Za-z]{1,28}(?:学部|研究科|学群|学域))/u,
    );
    if (faculty && !result.faculty) result.faculty = faculty[1];
    const year = line.match(
      /(?:^|[ :：]|学年\s*[:：]?\s*)(?:(修士|博士)\s*(?:課程)?\s*)?([1-6])\s*年(?:生|次)?(?:$|\s)/,
    );
    if (year && !result.schoolYear) {
      const v = (year[1] || '') + year[2] + '年';
      if ((schoolYears as readonly string[]).includes(v)) result.schoolYear = v;
    }
  }
  return result;
}
