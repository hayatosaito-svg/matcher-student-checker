import type { MatcherRegistration } from './matcher';

/** Public intake API. No credentials or spreadsheet identifiers belong here. */
export const MATCHER_API_URL =
  'https://gakusho-scan-glow.hayato-saito560683.chatgpt.site/api/matcher/register';

export function postMatcherRegistration(
  payload: MatcherRegistration,
  fetcher: typeof fetch = fetch,
): Promise<Response> {
  return fetcher(MATCHER_API_URL, {
    method: 'POST',
    mode: 'cors',
    credentials: 'omit',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(65000),
  });
}

/** Keep OCR assets inside either a project Pages path or a custom-domain root. */
export function ocrAssetPaths(documentBase: string) {
  return {
    workerPath: new URL('./ocr/worker.min.js', documentBase).href,
    corePath: new URL('./ocr/core', documentBase).href,
    langPath: new URL('./ocr/lang', documentBase).href,
  };
}
