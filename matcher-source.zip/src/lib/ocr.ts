import type { Worker } from 'tesseract.js';
import { ocrAssetPaths } from './runtime';
export type PreparedImage = { preview: string; ocr: string; upload: string };
export async function prepareImage(file: File): Promise<PreparedImage> {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type))
    throw new Error(
      'JPEG・PNG・WebP形式の写真を選んでください。HEIC画像はJPEGに変換してください。',
    );
  if (file.size > 15 * 1024 * 1024)
    throw new Error('写真は15MB以下のファイルを選んでください。');
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () =>
        reject(new Error('写真を開けませんでした。別の画像を選んでください。'));
      img.src = url;
    });
    if (img.width * img.height > 48_000_000)
      throw new Error(
        '画像の解像度が大きすぎます。サイズを小さくして選び直してください。',
      );
    const resize = (max: number, ocr: boolean, quality?: number) => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('お使いのブラウザで画像を処理できません。');
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      if (ocr) {
        const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const d = pixels.data;
        for (let i = 0; i < d.length; i += 4) {
          const gray = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
          const v = Math.max(0, Math.min(255, (gray - 128) * 1.6 + 140));
          d[i] = d[i + 1] = d[i + 2] = v;
        }
        ctx.putImageData(pixels, 0, 0);
      }
      const data = canvas.toDataURL(
        'image/jpeg',
        quality ?? (ocr ? 0.92 : 0.85),
      );
      canvas.width = canvas.height = 1;
      return data;
    };
    return {
      preview: resize(1100, false),
      ocr: resize(1600, true),
      upload: resize(1200, false, 0.85),
    };
  } finally {
    URL.revokeObjectURL(url);
  }
}
// The receiving sheet has one photo cell. Preserve both sides in that one file.
export async function composeEvidencePhoto(
  front: string,
  back?: string,
  evidence: 'id' | 'mypage' = 'id',
): Promise<string> {
  const sources = back ? [front, back] : [front];
  const images = await Promise.all(
    sources.map(
      (src) =>
        new Promise<HTMLImageElement>((resolve, reject) => {
          const image = new Image();
          image.onload = () => resolve(image);
          image.onerror = () =>
            reject(
              new Error(
                '送信用の画像を作成できませんでした。写真を選び直してください。',
              ),
            );
          image.src = src;
        }),
    ),
  );
  const padding = 24,
    labelHeight = 56;
  const width = Math.max(...images.map((image) => image.width)) + padding * 2;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = images.reduce(
    (height, image) => height + image.height + labelHeight + padding,
    padding,
  );
  const context = canvas.getContext('2d');
  if (!context) throw new Error('お使いのブラウザで画像を処理できません。');
  try {
    context.fillStyle = '#fff';
    context.fillRect(0, 0, canvas.width, canvas.height);
    let y = padding;
    images.forEach((image, index) => {
      context.fillStyle = '#192f51';
      context.font = 'bold 28px sans-serif';
      context.fillText(
        back
          ? index === 0
            ? '学生証 表面 / FRONT'
            : '学生証 裏面 / BACK'
          : evidence === 'id'
            ? '学生証 表面 / FRONT'
            : '大学マイページ',
        padding,
        y + 36,
      );
      y += labelHeight;
      context.drawImage(image, (width - image.width) / 2, y);
      y += image.height + padding;
    });
    for (const quality of [0.85, 0.75, 0.65, 0.55]) {
      const result = canvas.toDataURL('image/jpeg', quality);
      if (result.length <= 2700000) return result;
    }
    throw new Error(
      '送信用の画像が大きすぎます。余白を減らして撮影し直してください。',
    );
  } finally {
    canvas.width = canvas.height = 1;
  }
}
export async function readImage(
  image: string,
  onProgress: (label: string, value: number) => void,
) {
  const { createWorker } = await import('tesseract.js');
  let worker: Worker | undefined;
  let expired = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  const run = async () => {
    worker = await createWorker('jpn+eng', 1, {
      ...ocrAssetPaths(document.baseURI),
      cacheMethod: 'none',
      workerBlobURL: false,
      logger: (m) => {
        if (expired) return;
        const labels: Record<string, string> = {
          'loading tesseract core': '読み取りエンジンを準備中…',
          'initializing tesseract': '初期化中…',
          'loading language traineddata': '日本語・英語データを準備中…',
          'initializing api': '読み取りの準備中…',
        };
        const value =
          m.status === 'recognizing text'
            ? Math.round((m.progress || 0) * 100)
            : 0;
        onProgress(
          m.status === 'recognizing text'
            ? `解析中… ${value}%`
            : labels[m.status] || '準備中…',
          value,
        );
      },
    });
    if (expired) {
      await worker.terminate();
      throw new Error('読み取りがタイムアウトしました');
    }
    const result = await worker.recognize(image);
    return result.data.text.trim();
  };
  try {
    return await Promise.race([
      run(),
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => {
          expired = true;
          reject(
            new Error(
              '読み取りに時間がかかっています。通信環境を確認し、画像を小さくして再度お試しください。',
            ),
          );
        }, 120000);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
    if (worker) await worker.terminate();
  }
}
