'use client';
import { useEffect, useRef, useState } from 'react';
import { postMatcherRegistration } from '@/lib/runtime';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Progress } from '@/components/ui/progress';
import { EvidenceUpload } from '@/components/evidence-upload';
import {
  prepareImage,
  readImage,
  composeEvidencePhoto,
  type PreparedImage,
} from '@/lib/ocr';
import {
  schoolYears,
  matcherProfileError,
  extractMatcherProfile,
  type MatcherProfile,
  type MatcherRegistration,
  type ExtractedProfile,
} from '@/lib/matcher';
const labels = {
  uploaded: '今回アップロード',
  previous: '以前アップロード済み',
  skipped: '今回は提出しない',
};
export default function MatcherForm() {
  const [profile, setProfile] = useState<MatcherProfile>({
    name: '',
    faculty: '',
    schoolYear: '',
    lineUrl: '',
    referrerName: '',
  });
  const [step, setStep] = useState(1);
  const [submissionStatus, setSubmissionStatus] = useState<
    MatcherRegistration['submissionStatus'] | ''
  >('');
  const [evidence, setEvidence] = useState<'id' | 'mypage'>('id');
  const [photo, setPhoto] = useState<PreparedImage | null>(null);
  const [back, setBack] = useState<PreparedImage | null>(null);
  const [combined, setCombined] = useState<string | null>(null);
  const [extracted, setExtracted] = useState<ExtractedProfile | null>(null);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState({ label: '', value: 0 });
  const [message, setMessage] = useState('');
  const [privacy, setPrivacy] = useState(false);
  const [sendState, setSendState] = useState<
    'idle' | 'sending' | 'success' | 'rejected' | 'unknown'
  >('idle');
  const pending = useRef<MatcherRegistration | null>(null);
  const requestId = useRef('');
  const lock = useRef(false);
  const section = useRef<HTMLElement>(null);
  const disabled = busy || sendState === 'sending' || sendState === 'unknown';
  useEffect(() => {
    requestId.current = crypto.randomUUID();
  }, []);
  useEffect(() => {
    section.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [step]);
  function clearScan() {
    setPhoto(null);
    setBack(null);
    setCombined(null);
    setExtracted(null);
    setMessage('');
    setPrivacy(false);
  }
  async function choose(side: 'front' | 'back', file?: File) {
    if (!file || lock.current) return;
    lock.current = true;
    setBusy(true);
    setCombined(null);
    setExtracted(null);
    setMessage('');
    setPrivacy(false);
    if (side === 'front') setPhoto(null);
    else setBack(null);
    try {
      const image = await prepareImage(file);
      if (side === 'front') setPhoto(image);
      else setBack(image);
    } catch (e) {
      setMessage(
        e instanceof Error ? e.message : '画像を読み込めませんでした。',
      );
    } finally {
      setBusy(false);
      lock.current = false;
    }
  }
  async function scan() {
    if (!photo || lock.current) return;
    lock.current = true;
    setBusy(true);
    setMessage('');
    try {
      const pages = evidence === 'id' && back ? [photo, back] : [photo];
      const merged = await composeEvidencePhoto(
        photo.upload,
        evidence === 'id' ? back?.upload : undefined,
        evidence,
      );
      setCombined(merged);
      let found: ExtractedProfile = { name: '', faculty: '', schoolYear: '' };
      try {
        const texts: string[] = [];
        for (let i = 0; i < pages.length; i++)
          texts.push(
            await readImage(pages[i].ocr, (label, value) =>
              setProgress({
                label,
                value: Math.round((i * 100 + value) / pages.length),
              }),
            ),
          );
        found = extractMatcherProfile(texts.join('\n'));
      } catch {
        setMessage(
          '画像は準備できました。文字を読み取れなかったため、4項目を入力してください。',
        );
      }
      setExtracted(found);
      setProfile((s) => ({
        ...s,
        name: s.name || found.name,
        faculty: s.faculty || found.faculty,
        schoolYear: s.schoolYear || found.schoolYear,
      }));
      setStep(2);
    } catch (e) {
      setMessage(
        e instanceof Error ? e.message : '画像を準備できませんでした。',
      );
    } finally {
      setBusy(false);
      lock.current = false;
    }
  }
  async function send(payload: MatcherRegistration) {
    if (lock.current) return;
    lock.current = true;
    setSendState('sending');
    setMessage('');
    try {
      const response = await postMatcherRegistration(payload);
      const value = (await response.json()) as {
        status?: string;
        requestId?: string;
        message?: string;
      };
      if (
        response.ok &&
        value.status === 'success' &&
        value.requestId === payload.requestId
      ) {
        setSendState('success');
        setStep(4);
        return;
      }
      if (
        value.status === 'rejected' &&
        [400, 403, 413, 415, 503].includes(response.status)
      ) {
        setSendState('rejected');
        setMessage(value.message || '入力内容をご確認ください。');
        return;
      }
    } catch {
      /* The retry below keeps the identical receipt and payload. */
    } finally {
      lock.current = false;
    }
    setSendState('unknown');
    setMessage(
      '受付結果を確認できませんでした。下のボタンで同じ受付の保存状況を確認できます。',
    );
  }
  function complete(e: React.FormEvent) {
    e.preventDefault();
    const error = matcherProfileError(profile);
    if (error) {
      setMessage(error);
      setStep(2);
      return;
    }
    if (
      !submissionStatus ||
      (submissionStatus === 'uploaded' && (!combined || !extracted))
    ) {
      setMessage('提出方法を選び直してください。');
      setStep(1);
      return;
    }
    if (!privacy) {
      setMessage('情報の取り扱いをご確認ください。');
      return;
    }
    if (!requestId.current) requestId.current = crypto.randomUUID();
    const payload: MatcherRegistration = {
      schemaVersion: 2,
      requestId: requestId.current,
      profile,
      submissionStatus,
      evidence: submissionStatus === 'uploaded' ? evidence : null,
      photo: submissionStatus === 'uploaded' ? combined : null,
      photoCount:
        submissionStatus === 'uploaded'
          ? evidence === 'id' && back
            ? 2
            : 1
          : 0,
      extracted: submissionStatus === 'uploaded' ? extracted : null,
      consent: { privacy: true },
    };
    pending.current = payload;
    void send(payload);
  }
  function field(
    key: 'name' | 'faculty' | 'lineUrl' | 'referrerName',
    label: string,
    placeholder: string,
    required = true,
  ) {
    return (
      <label className="gs-label">
        {label}（{required ? '必須' : '任意'}）
        <input
          className="gs-input"
          name={key}
          type={key === 'lineUrl' ? 'url' : 'text'}
          value={profile[key]}
          placeholder={placeholder}
          required={required}
          maxLength={key === 'lineUrl' ? 500 : 200}
          onChange={(e) => setProfile((s) => ({ ...s, [key]: e.target.value }))}
        />
      </label>
    );
  }
  return (
    <main className="gs-root gs-bizreq gs-matcher">
      <header className="gs-topbar">
        <div className="gs-brand">
          <span className="gs-brand-mark" aria-hidden>
            BR
          </span>
          <div>
            <h1>ビズリク｜学生証チェッカー</h1>
            <p>Matcherからご案内された方へ</p>
          </div>
        </div>
      </header>
      <div className="gs-shell">
        <ol className="gs-steps" aria-label="登録の手順">
          {['学生証（任意）', '4項目を入力', '内容の確認', '登録完了'].map(
            (s, i) => (
              <li
                key={s}
                className={`gs-step ${step === i + 1 ? 'on' : ''}`}
                aria-current={step === i + 1 ? 'step' : undefined}
              >
                {i + 1}. {s}
              </li>
            ),
          )}
        </ol>
        {step === 1 && (
          <section className="gs-card" ref={section}>
            <h2>学生証の提出方法</h2>
            <p className="gs-mini gs-section-gap">
              登録に必要なのは氏名・学部・学年・LINE
              URLの4項目です。学生証は任意。読み取れた情報は次の画面に反映します。
            </p>
            <RadioGroup
              className="matcher-options gs-section-gap"
              value={submissionStatus}
              disabled={disabled}
              onValueChange={(v) => {
                setSubmissionStatus(
                  v as MatcherRegistration['submissionStatus'],
                );
                clearScan();
              }}
              aria-label="学生証の提出方法"
            >
              {Object.entries(labels).map(([v, label]) => (
                <label className="gs-status-opt" key={v}>
                  <RadioGroupItem value={v} />
                  {label}
                </label>
              ))}
            </RadioGroup>
            {submissionStatus === 'uploaded' && (
              <div className="gs-section-gap">
                <RadioGroup
                  className="gs-status-group"
                  value={evidence}
                  disabled={disabled}
                  onValueChange={(v) => {
                    setEvidence(v as 'id' | 'mypage');
                    clearScan();
                  }}
                  aria-label="書類の種類"
                >
                  {[
                    ['id', '学生証'],
                    ['mypage', '大学マイページ'],
                  ].map(([v, label]) => (
                    <label className="gs-status-opt" key={v}>
                      <RadioGroupItem value={v} />
                      {label}
                    </label>
                  ))}
                </RadioGroup>
                <p className="gs-mini gs-section-gap">
                  氏名・学部・学年が見える画像を選んでください。記載のない項目は次の画面で入力できます。
                </p>
                <div className="gs-evidence-grid gs-section-gap">
                  <EvidenceUpload
                    label={evidence === 'id' ? '表面' : '大学マイページ'}
                    photo={photo}
                    disabled={disabled}
                    onChoose={(f) => void choose('front', f)}
                    onClear={() => {
                      setPhoto(null);
                      setCombined(null);
                      setExtracted(null);
                    }}
                  />
                  {evidence === 'id' && (
                    <EvidenceUpload
                      label="裏面"
                      required={false}
                      photo={back}
                      disabled={disabled}
                      onChoose={(f) => void choose('back', f)}
                      onClear={() => {
                        setBack(null);
                        setCombined(null);
                        setExtracted(null);
                      }}
                    />
                  )}
                </div>
                {busy && (
                  <div aria-live="polite" className="gs-section-gap">
                    <p className="gs-mini">
                      {progress.label || '画像を準備しています…'}
                    </p>
                    <Progress
                      value={progress.value}
                      aria-label="読み取りの進捗"
                    />
                  </div>
                )}
              </div>
            )}
            <button
              className="gs-btn gs-btn-primary gs-section-gap"
              disabled={
                disabled ||
                !submissionStatus ||
                (submissionStatus === 'uploaded' && !photo)
              }
              onClick={() => {
                if (submissionStatus === 'uploaded') void scan();
                else {
                  setMessage('');
                  setStep(2);
                }
              }}
            >
              {submissionStatus === 'uploaded'
                ? '読み取って次へ'
                : '4項目の入力へ'}
            </button>
          </section>
        )}
        {step === 2 && (
          <section className="gs-card" ref={section}>
            <h2>4項目を入力</h2>
            <p className="gs-mini gs-section-gap">
              {submissionStatus === 'uploaded'
                ? '読み取り結果を確認し、空欄や誤りを修正してください。'
                : '次の4項目をご入力ください。'}
            </p>
            <form
              className="gs-section-gap"
              onSubmit={(e) => {
                e.preventDefault();
                const error = matcherProfileError(profile);
                setMessage(error);
                if (!error) {
                  setPrivacy(false);
                  setStep(3);
                }
              }}
            >
              <fieldset disabled={disabled}>
                <div className="gs-grid matcher-fields">
                  {field('name', '氏名', '例：山田 太郎')}
                  {field('faculty', '学部', '例：経済学部')}
                  <label className="gs-label">
                    学年（必須）
                    <select
                      className="gs-input"
                      name="schoolYear"
                      required
                      value={profile.schoolYear}
                      onChange={(e) =>
                        setProfile((s) => ({
                          ...s,
                          schoolYear: e.target.value,
                        }))
                      }
                    >
                      <option value="">選択してください</option>
                      {schoolYears.map((y) => (
                        <option key={y}>{y}</option>
                      ))}
                    </select>
                  </label>
                  {field('lineUrl', 'LINE URL', 'https://line.me/ti/p/…')}
                </div>
                <p className="gs-mini gs-section-gap">
                  LINE
                  URLは、ご自身の友だち追加URLを貼り付けてください。学生証からは読み取れません。
                </p>
                <details className="gs-legal gs-section-gap">
                  <summary>LINE URLの取得方法</summary>
                  <p>
                    LINEのトーク画面上部の「＋」→「マイQRコード」→「リンクをコピー」を選び、この欄に貼り付けてください。
                    <a
                      href="https://help.line.me/line/?contentId=200000585&amp;lang=ja"
                      target="_blank"
                      rel="noreferrer"
                    >
                      LINE公式ヘルプ
                    </a>
                  </p>
                </details>
                <div className="gs-section-gap">
                  {field(
                    'referrerName',
                    '紹介者のお名前',
                    '例：齋藤さん',
                    false,
                  )}
                </div>
                <div className="gs-row gs-section-gap">
                  <button
                    type="button"
                    className="gs-btn gs-btn-ghost"
                    onClick={() => {
                      setMessage('');
                      setStep(1);
                    }}
                  >
                    戻る
                  </button>
                  <button className="gs-btn gs-btn-primary" type="submit">
                    内容を確認する
                  </button>
                </div>
              </fieldset>
            </form>
          </section>
        )}
        {step === 3 && (
          <section className="gs-card" ref={section}>
            <h2>登録内容の確認</h2>
            <dl className="matcher-summary gs-section-gap">
              {[
                ['氏名', profile.name],
                ['学部', profile.faculty],
                ['学年', profile.schoolYear],
                ['LINE URL', profile.lineUrl],
                ['紹介者', profile.referrerName || '未入力'],
                ['学生証', submissionStatus ? labels[submissionStatus] : ''],
              ].map(([key, value]) => (
                <div key={key}>
                  <dt>{key}</dt>
                  <dd>{value}</dd>
                </div>
              ))}
            </dl>
            <form className="gs-section-gap" onSubmit={complete}>
              <fieldset disabled={disabled}>
                <details className="gs-legal">
                  <summary>情報の取り扱いについて</summary>
                  <p>
                    株式会社ビズリクが、学生情報の確認と面談・就職活動のサポート、ご本人への連絡のために入力内容と提出画像を利用します。学生証の提出は任意です。読み取り結果は参考情報として担当者が確認します。
                  </p>
                </details>
                <label className="gs-check">
                  <Checkbox
                    checked={privacy}
                    onCheckedChange={(v) => setPrivacy(v === true)}
                  />
                  情報の取り扱いを確認し、入力内容の登録に同意します。
                </label>
                <div className="gs-row gs-section-gap">
                  <button
                    type="button"
                    className="gs-btn gs-btn-ghost"
                    onClick={() => {
                      setMessage('');
                      setStep(2);
                    }}
                  >
                    修正する
                  </button>
                  <button
                    type="submit"
                    className="gs-btn gs-btn-primary"
                    disabled={!privacy}
                  >
                    {sendState === 'sending'
                      ? '登録しています…'
                      : 'この内容で登録する'}
                  </button>
                </div>
              </fieldset>
            </form>
            {sendState === 'unknown' && (
              <button
                className="gs-btn gs-btn-primary gs-section-gap"
                onClick={() => {
                  if (pending.current) void send(pending.current);
                }}
              >
                同じ受付の保存状況を確認する
              </button>
            )}
          </section>
        )}
        {step === 4 && (
          <section className="gs-card" ref={section}>
            <div className="gs-success-icon" aria-hidden>
              ✓
            </div>
            <h2>登録が完了しました</h2>
            <p className="gs-section-gap">
              ご入力ありがとうございます。担当者が内容を確認します。
            </p>
            <p className="gs-mini gs-section-gap">
              受付番号：{requestId.current}
            </p>
          </section>
        )}
        {message && (
          <p className="gs-message gs-section-gap" role="alert">
            {message}
          </p>
        )}
        <footer className="gs-mini gs-section-gap">株式会社ビズリク</footer>
      </div>
    </main>
  );
}
