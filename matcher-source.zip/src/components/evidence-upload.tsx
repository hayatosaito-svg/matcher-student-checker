'use client';
import { useRef, useState } from 'react';
import type { PreparedImage } from '@/lib/ocr';

export function EvidenceUpload({
  label,
  required = true,
  photo,
  disabled,
  onChoose,
  onClear,
}: {
  label: string;
  required?: boolean;
  photo: PreparedImage | null;
  disabled: boolean;
  onChoose: (file?: File) => void;
  onClear: () => void;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState(false);
  return (
    <div className="gs-evidence-side">
      <h3 className="gs-label">
        {label}（{required ? '必須' : '任意'}）
      </h3>
      <div
        className={`gs-drop ${drag ? 'drag' : ''}`}
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled) setDrag(true);
        }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          if (!disabled) onChoose(e.dataTransfer.files[0]);
        }}
      >
        <input
          ref={input}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          hidden
          disabled={disabled}
          onChange={(e) => {
            onChoose(e.target.files?.[0]);
            e.target.value = '';
          }}
          aria-label={`${label}の画像を選択`}
        />
        <button
          type="button"
          className="gs-btn gs-btn-primary"
          disabled={disabled}
          onClick={() => input.current?.click()}
        >
          {label}を選ぶ / 撮影する
        </button>
        <p className="gs-section-gap">JPEG・PNG・WebP／1枚15MBまで</p>
      </div>
      {photo && (
        <>
          <div className="gs-scanbox">
            <img src={photo.preview} alt={`${label}のプレビュー`} />
          </div>
          <button
            type="button"
            className="gs-btn gs-btn-ghost gs-section-gap"
            disabled={disabled}
            onClick={onClear}
          >
            {label}を削除
          </button>
        </>
      )}
    </div>
  );
}
