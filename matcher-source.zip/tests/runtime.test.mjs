import test from 'node:test';
import assert from 'node:assert/strict';
import { MATCHER_API_URL, postMatcherRegistration, ocrAssetPaths } from '../src/lib/runtime.ts';

test('GitHub project Pages retains its repository path for all OCR assets', () => {
  for (const page of [
    'https://sample.github.io/matcher-registration/',
    'https://sample.github.io/matcher-registration/index.html?ref=sample',
  ]) {
    assert.deepEqual(ocrAssetPaths(page), {
      workerPath: 'https://sample.github.io/matcher-registration/ocr/worker.min.js',
      corePath: 'https://sample.github.io/matcher-registration/ocr/core',
      langPath: 'https://sample.github.io/matcher-registration/ocr/lang',
    });
  }
});

test('custom-domain root uses the same relative OCR files', () => {
  assert.equal(ocrAssetPaths('https://example.invalid/').workerPath,
    'https://example.invalid/ocr/worker.min.js');
});

test('cross-origin request keeps receipt and body, omits credentials, and returns response unchanged', async () => {
  const payload = {
    schemaVersion: 2,
    requestId: 'a194f3b9-9cc0-4926-8ad9-563197199a7f',
    profile: { name: '動作確認専用', faculty: '動作確認専用学部', schoolYear: '3年',
      lineUrl: 'https://line.me/ti/p/MATCHER_SMOKE_NOT_REAL', referrerName: '' },
    submissionStatus: 'previous', evidence: null, photo: null,
    photoCount: 0, extracted: null, consent: { privacy: true },
  };
  const calls = [];
  const response = new Response(JSON.stringify({ status: 'success', requestId: payload.requestId }));
  const fetcher = async (url, options) => { calls.push({ url, options }); return response; };
  assert.equal(await postMatcherRegistration(payload, fetcher), response);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, MATCHER_API_URL);
  assert.equal(new URL(calls[0].url).pathname, '/api/matcher/register');
  assert.equal(calls[0].options.credentials, 'omit');
  assert.equal(calls[0].options.mode, 'cors');
  assert.equal(calls[0].options.method, 'POST');
  assert.deepEqual(calls[0].options.headers, { 'Content-Type': 'application/json' });
  assert.deepEqual(JSON.parse(calls[0].options.body), payload);
  assert.equal(calls[0].options.signal.aborted, false);
});

test('unknown transport failures do not create automatic duplicate requests', async () => {
  let calls = 0;
  await assert.rejects(postMatcherRegistration({}, async () => {
    calls++;
    throw new TypeError('Synthetic network failure');
  }), TypeError);
  assert.equal(calls, 1);
});
