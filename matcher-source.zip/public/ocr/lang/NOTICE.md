Japanese and English trained data for Tesseract.
Source: @tesseract.js-data/jpn and @tesseract.js-data/eng, 4.0.0_best_int.
https://github.com/naptha/tessdata
https://github.com/tesseract-ocr/tessdata_best
Apache License 2.0; see ../core/LICENSE.
